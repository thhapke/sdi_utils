# Filters the names with today substring - sdi_utils_operators.filter_today (Version: 0.0.1)

Filters the names with today substring.

## Inport

* **input_files** (Type: message) List of filenames

## outports

* **log** (Type: string) Logging data
* **output_files** (Type: message) Filename

## Config

* **debug_mode** - Debug mode (Type: boolean) Sending debug level information to log port


# Tags
sdi_utils : 

